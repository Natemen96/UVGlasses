package graphes;

/**
 * Created by Andrew on 7/20/17.
 */

public interface GraphHandler
{
    interface Progress
    {
        int READY = 1;

    }
}
