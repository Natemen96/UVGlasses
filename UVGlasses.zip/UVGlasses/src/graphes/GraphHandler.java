package graphes;



public interface GraphHandler
{
    interface Progress
    {
        int READY = 1;

    }
}
